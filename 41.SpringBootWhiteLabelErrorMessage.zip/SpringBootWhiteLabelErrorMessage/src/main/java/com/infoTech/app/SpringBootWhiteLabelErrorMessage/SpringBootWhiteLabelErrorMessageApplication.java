package com.infoTech.app.SpringBootWhiteLabelErrorMessage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWhiteLabelErrorMessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWhiteLabelErrorMessageApplication.class, args);
	}

}
