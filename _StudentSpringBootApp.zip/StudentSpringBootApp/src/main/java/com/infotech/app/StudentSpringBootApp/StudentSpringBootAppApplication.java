package com.infotech.app.StudentSpringBootApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSpringBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSpringBootAppApplication.class, args);
	}

}
